package com.customer.service;

import java.security.PublicKey;
import java.util.List;

import org.springframework.stereotype.Service;

import com.customer.domain.Hotel_customer;

@Service
public class Service_interface implements Hotel_service
{
	List<Hotel_customer> customers = List.of(new Hotel_customer(69L,"Adil",5L,"25 min"),new Hotel_customer(70L,"Manish",7L,"15 min"),
			new Hotel_customer(30L,"Nitish",2L,"40 min"),new Hotel_customer(19L,"Kshitiz",1L,"10 min"));
			
		
//			Long table_no, String customer_name, String order_no, Long cooking_time

@Override
public Hotel_customer gettable_no(Long table_no)
{
	
	return customers.stream().filter(hotel_customers -> hotel_customers.getTable_no().equals(table_no)).findAny().orElse(null);
	
}
}