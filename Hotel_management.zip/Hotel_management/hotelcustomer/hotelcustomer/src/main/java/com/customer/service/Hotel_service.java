package com.customer.service;

import com.customer.domain.Hotel_customer;

public interface Hotel_service 
{
	public Hotel_customer gettable_no(Long table_no);
	
}
