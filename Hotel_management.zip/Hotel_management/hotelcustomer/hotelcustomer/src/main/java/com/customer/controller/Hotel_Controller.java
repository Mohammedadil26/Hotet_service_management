package com.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.customer.domain.Hotel_customer;
import com.customer.service.Hotel_service;

@RestController
@RequestMapping("/customer") 
public class Hotel_Controller 
{
 @Autowired
 private Hotel_service hotel_service;
 
 @Autowired
 private RestTemplate resttemplate;
 
 @GetMapping("/{table_no}")
  public Hotel_customer gettable(@PathVariable("table_no") Long table_no) 
 {
	 Hotel_customer hotel_customer = this.hotel_service.gettable_no(table_no);
	 List hotel_bills= this.resttemplate.getForObject("http://hotel_bill-hotel_customer/hotel_bill/hotel_customer/"+hotel_customer.getTable_no(),List.class);
	 hotel_customer.setHotel_bills(hotel_bills);
	 return hotel_customer;
	 
 }
 
	
}
