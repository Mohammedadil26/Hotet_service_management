package com.customer.domain;

import java.util.ArrayList;
import java.util.List;

public class Hotel_customer 
{
	private Long table_no;
	private String customer_name;
	private Long order_no;
	private String cooking_time;
	
	List<Hotel_bill> hotel_bills = new ArrayList<>();

	public Hotel_customer(Long table_no, String customer_name, Long order_no, String cooking_time,
			List<Hotel_bill> hotel_bills) {
		super();
		this.table_no = table_no;
		this.customer_name = customer_name;
		this.order_no = order_no;
		this.cooking_time = cooking_time;
		this.hotel_bills = hotel_bills;
	}

	public Hotel_customer(Long table_no, String customer_name, Long order_no, String cooking_time) {
		super();
		this.table_no = table_no;
		this.customer_name = customer_name;
		this.order_no = order_no;
		this.cooking_time = cooking_time;
	}

	public Hotel_customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getTable_no() {
		return table_no;
	}

	public void setTable_no(Long table_no) {
		this.table_no = table_no;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public Long getOrder_no() {
		return order_no;
	}

	public void setOrder_no(Long order_no) {
		this.order_no = order_no;
	}

	public String getCooking_time() {
		return cooking_time;
	}

	public void setCooking_time(String cooking_time) {
		this.cooking_time = cooking_time;
	}

	public List<Hotel_bill> getHotel_bills() {
		return hotel_bills;
	}

	public void setHotel_bills(List<Hotel_bill> hotel_bills) {
		this.hotel_bills = hotel_bills;
	}

	
	
	
	
	

}
