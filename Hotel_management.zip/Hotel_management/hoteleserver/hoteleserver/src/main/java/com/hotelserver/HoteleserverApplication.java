package com.hotelserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class HoteleserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(HoteleserverApplication.class, args);
	}

}
