package com.bill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelbillApplicationTests {

	@Test
	void contextLoads() {
	}

}
