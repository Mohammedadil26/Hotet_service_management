package com.bill.service;

import java.util.List;
import java.util.stream.Collectors;
import com.bill.domain.Hotel_bill;

public class Bill_service implements Bill_interface
{
	 List<Hotel_bill> list = List.of(new Hotel_bill(69L,"Kadai_paneer",1000L),new Hotel_bill(70L,"chole_makhani",1001L),
			 new Hotel_bill(30L,"Biryani",1003L),new Hotel_bill(19L,"white pasta",1004L));

	@Override
	public List<Hotel_bill> getbilltable_no(Long table_no) {
		// TODO Auto-generated method stub
		return list.stream().filter(hotel_bill -> hotel_bill.getTable_no().equals(table_no)).collect(Collectors.toList());
	}
	
	 
	 
}
