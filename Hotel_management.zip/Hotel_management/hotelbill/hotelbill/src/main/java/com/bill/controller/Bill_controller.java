package com.bill.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bill.domain.Hotel_bill;
import com.bill.service.Bill_interface;

@RequestMapping("/bill")
@RestController
public class Bill_controller 
{
	@Autowired
	private Bill_interface bill_interface;
	
	@RequestMapping("/customer/{table_no}")
	public List<Hotel_bill> getHotel_bills(@PathVariable("table_no") Long table_no)
	{
		return this.bill_interface.getbilltable_no(table_no);
	}
	
}
