package com.bill.service;

import java.util.List;

import com.bill.domain.Hotel_bill;

public interface Bill_interface 
{
	public List<Hotel_bill> getbilltable_no(Long table_no);
}
