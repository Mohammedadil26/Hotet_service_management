package com.bill.domain;

public class Hotel_bill
{
	private Long table_no;
	private String food_detail;
	private Long table_bill;
	public Hotel_bill(Long table_no, String food_detail, Long table_bill) {
		super();
		this.table_no = table_no;
		this.food_detail = food_detail;
		this.table_bill = table_bill;
	}
	public Hotel_bill() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getTable_no() {
		return table_no;
	}
	public void setTable_no(Long table_no) {
		this.table_no = table_no;
	}
	public String getFood_detail() {
		return food_detail;
	}
	public void setFood_detail(String food_detail) {
		this.food_detail = food_detail;
	}
	public Long getTable_bill() {
		return table_bill;
	}
	public void setTable_bill(Long table_bill) {
		this.table_bill = table_bill;
	}
	 
	  
	  
	}
